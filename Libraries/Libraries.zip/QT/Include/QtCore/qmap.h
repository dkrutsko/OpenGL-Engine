#include "../../src/corelib/tools/qmap.h"
