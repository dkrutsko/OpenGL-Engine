#include "../../src/corelib/arch/qatomic_alpha.h"
