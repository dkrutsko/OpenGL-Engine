#include "../../../src/corelib/io/qfilesystemwatcher_dnotify_p.h"
