#include "../../../src/corelib/tools/qlocale_data_p.h"
