#include "../../../src/corelib/plugin/qfactoryloader_p.h"
