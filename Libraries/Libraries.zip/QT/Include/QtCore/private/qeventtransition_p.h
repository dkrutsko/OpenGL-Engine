#include "../../../src/corelib/statemachine/qeventtransition_p.h"
