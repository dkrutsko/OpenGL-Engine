#include "../../../src/corelib/statemachine/qsignaltransition_p.h"
