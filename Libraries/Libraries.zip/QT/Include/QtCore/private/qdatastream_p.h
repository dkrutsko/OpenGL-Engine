#include "../../../src/corelib/io/qdatastream_p.h"
