#include "../../../src/corelib/tools/qlocale_tools_p.h"
