#include "../../../src/corelib/kernel/qeventdispatcher_symbian_p.h"
