#include "../../src/corelib/arch/qatomic_powerpc.h"
