#include "../../src/corelib/arch/qatomic_sh.h"
