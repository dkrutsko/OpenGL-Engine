#include "../../src/corelib/kernel/qobjectdefs.h"
