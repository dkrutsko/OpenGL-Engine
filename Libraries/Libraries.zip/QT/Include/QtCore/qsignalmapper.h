#include "../../src/corelib/kernel/qsignalmapper.h"
