#include "../../src/corelib/arch/qatomic_s390.h"
