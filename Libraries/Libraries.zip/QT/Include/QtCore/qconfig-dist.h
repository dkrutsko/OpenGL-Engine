#include "../../src/corelib/global/qconfig-dist.h"
