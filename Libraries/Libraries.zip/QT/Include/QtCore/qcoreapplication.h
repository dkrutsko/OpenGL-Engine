#include "../../src/corelib/kernel/qcoreapplication.h"
