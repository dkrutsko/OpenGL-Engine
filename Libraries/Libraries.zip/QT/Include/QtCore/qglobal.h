#include "../../src/corelib/global/qglobal.h"
