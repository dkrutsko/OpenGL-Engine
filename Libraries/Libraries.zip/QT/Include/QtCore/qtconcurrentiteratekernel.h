#include "../../src/corelib/concurrent/qtconcurrentiteratekernel.h"
