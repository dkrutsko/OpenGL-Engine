#include "../../src/corelib/kernel/qfunctions_vxworks.h"
