#include "../../src/corelib/codecs/qtextcodecplugin.h"
