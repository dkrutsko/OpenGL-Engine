#include "../../src/corelib/global/qconfig-minimal.h"
